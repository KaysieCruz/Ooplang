
import javax.swing.*;
import java.awt.*;
import javax.swing.JTextField;
import java.awt.event.*;
public class BMI extends JFrame
{
    JButton BMIbutton = new JButton();
    JButton Clearbutton = new JButton();
    JButton Exitbutton = new JButton();
    
    JLabel HeightLabel = new JLabel();
    JLabel WeightLabel = new JLabel();
    JLabel BMILabel = new JLabel();
    JLabel FeetLabel = new JLabel();
    JLabel InchLabel = new JLabel();
    JLabel poundsLabel = new JLabel();
    
    JTextField heightTextField = new JTextField();
    JTextField weightTextField = new JTextField();
    JTextField BMITextField = new JTextField();
    JTextField inchesTextField = new JTextField();
    
    float BMI;
    float height;
    float weight;
    int feet;
    int inches;
    float pounds;
    
    public BMI
    {
        setText("BMI Calculator");
        getContentPane().setLayout(GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();
        
        setText.BMIbutton("Compute BMI");
        gridConstraints gridx = 0;
        gridConstraints gridy = 3;
        getContentPane().addBMIbutton(BMIbutton,gridConstraints);
    
        
        setText.Clearbutton("Clear");
        gridConstraints gridx = 1;
        gridConstraints gridy = 3;
        getContentPane().addClearbutton(Clearbutton, gridConstraints);
        
        setText.Exitbutton("Exit");
        gridConstraints gridx = 2;
        gridConstraints gridy = 3;
        getContentPane().addExitbutton(Exitbutton,gridConstraints);
        
        setText.HeightLabel("Height");
        gridConstraints gridx = 0;
        gridConstraints gridy = 0;
        getContentPane().addHeightLabel(HeightLabel, gridConstraints);
        
        setText.WeightLabel("Weight");
        gridConstraints gridx = 0;
        gridConstraints gridy = 1;
        getContentPane().addWeightLabel(WeightLabel, gridConstraints);
        
        setText.BMILabel("BMI");
        gridConstraints gridx = 0;
        gridConstraints gridy = 0;
        getContentPane().addBMILabel(BMILabel, gridConstraints);
        
        setText.FeetLabel("feet");
        gridConstraints gridx = 3;
        gridConstraints gridy = 0;
        getContentPane().addFeetLabel(FeetLabel, gridConstraints);
        
        setText.InchLabel("inches");
        gridConstraints gridx = 5;
        gridConstraints gridy = 0;
        getContentPane().addInchLabel(InchLabel, gridConstraints);
        
        setText.poundsLabel("BMI");
        gridConstraints gridx = 0;
        gridConstraints gridy = 0;
        getContentPane().addpoundsLabel(poundsLabel, gridConstraints);
        
        setText.heightTextField(" ");
        girdContraints Columns = 15;
        gridConstraints gridx = 1;
        gridConstraints gridy = 0;
        
        setText.weightTextField(" ");
        gridConstraints Columns = 15;
        gridConstraints gridx = 1;
        gridConstraints gridy = 1;
        getContentPane().addweightTextField(weightTextField, gridConstraints);
        
        setText.BMITextField(" ");
        gridConstraints Columns = 15;
        gridConstraints gridx = 1;
        gridConstraints gridy = 2;
        getContentPane().addBMITextField(BMITextField, gridConstraints);
        
        setText.inchesTextField(" ");
        gridConstraints Columns = 15;
        gridConstraints gridx = 4;
        gridConstraints gridy = 0;
        getContentPane().addinchesTextField(inchesTextField, gridConstraints);
        
        setText.feetTextField(" ");
        gridContraints Columns = 15;
        gridConstraints gridx = 3;
        gridConstraints gridy = 0;
        getContentPane().addfeetTextField(feetTextField, gridConstraints);
    
        
        pack();
        
        WindowListener windowClosing(new WindowAdapter){
            exitform(e);
        });
        
        
    }
    private computeButton actionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f,"Computing BMI...");
    }
    private Clearbutton actionPerformed(ActionEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f,"Cleared");
    }
    private exitform windowClosing(WindowEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f,"Exiting Module");
    }
    private WindowListener Windowclosing(WindowEvent e){
        JFrame f;
        f = new JFrame();
        JOptionPane.showMessageDialog(f,"Exiting");
    }
    public static void main(String[]args){
        BMI.show();
    }
    

}
